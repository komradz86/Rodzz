	
![[Pasted image 20250303131221.png]]


![[Pasted image 20250303131251.png]]


Rubber ducky working

![[Pasted image 20250305225550.png]]

![[Pasted image 20250305231653.png]]


port query
![[Pasted image 20250305231726.png]]

![[Pasted image 20250305231752.png]]



![[Pasted image 20250305231818.png]]


![[Pasted image 20250305234221.png]]


![[Pasted image 20250305234325.png]]

![[Pasted image 20250305234357.png]]

![[Pasted image 20250305235537.png]]
![[Pasted image 20250306000358.png]]

\\10.2.0.114\mctools\mc_prod\NAV_To_KTP\Thierry_working_files

![[Pasted image 20250306232448.png]]

![[Pasted image 20250306232549.png]]

![[Pasted image 20250306232703.png]]

![[Pasted image 20250306232937.png]]

![[Pasted image 20250306233018.png]]



![[Pasted image 20250306233914.png]]\\10.30.0.3\shares\Data\PARTAGE\Venus Pictures\Christmas Lunch 2016

![[Pasted image 20250307222752.png]]

![[Pasted image 20250307222931.png]]

